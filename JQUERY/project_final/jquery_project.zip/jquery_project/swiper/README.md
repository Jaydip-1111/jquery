# multi-parallax-sliders
Two parallax sliders with animation using Swiper JS and jQuery

## Overview
For the carousels, I'll be using the Swiper JS plugin.
Images were taken from Pexels.